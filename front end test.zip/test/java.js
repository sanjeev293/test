$(".input").click(function(){
   document.getElementsByClassName("input");
})